// CS1300 Spring 2019
// Author: Trevor Green
// Recitation: T. Umada
// Cloud9 Workspace Editor Link:https://ide.c9.io/trgr5899/csci_1300_trevor_green
// Project 2
/*Algorithm-creating Library class
*create a class that combines the user and book functions 
*/
#ifndef LIBRARY_H
#define LIBRARY_H
#include <iostream>
#include <math.h>
#include <iomanip>
#include <string>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <fstream>
#include <stdio.h>
#include "User.h"
#include "Book.h"
#include <string.h>
using namespace std;
/**
  Library
 */
class Library
{
private:
   const static int sizeBook=50;
   const static int sizeUser=100;
   Book books[sizeBook];
   User users[sizeUser];
   int numBooks=0;
   int numUsers=0;
   
public:
   Library(); // default constructor
   int getSizeBook();
   int getSizeUser();
   int getNumBooks();
   int getNumUsers();
   int readBooks(string file);
   void printAllBooks();
   int readRatings(string file);
   int getRating(string username,string title);
   int getCountReadBooks(string username);
   void viewRatings(string username);
   double calcAvgRating(string title);
   int addUser(string username);
   int checkOutBook(string username, string title, int rating);
   void getRecommendations(string username);
   
   
   
};

#endif