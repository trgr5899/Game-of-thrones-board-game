// CS1300 Spring 2019
// Author: Trevor Green
// Recitation: T. Umada
// Cloud9 Workspace Editor Link:https://ide.c9.io/trgr5899/csci_1300_trevor_green
// Project 2
/*Algorithm-
*create functions that get and set book title and author for Book class
*/
#include <iostream>
#include <math.h>
#include <iomanip>
#include <string>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <fstream>
#include "Book.h"
#include <stdio.h>
#include <string.h>
using namespace std;

Book::Book()
{
    title="";
    author="";
}
Book::Book(string titl,string auth)
{
    title=titl;
    author=auth;
}
void Book::setTitle(string titl)
{
    title=titl;
}
string Book::getTitle()
{
    return title;
}
string Book::getAuthor()
{
    return author;
}
void Book::setAuthor(string auth)
{
    author=auth;
}
