// CS1300 Spring 2019
// Author: Trevor Green
// Recitation: T. Umada
// Cloud9 Workspace Editor Link:https://ide.c9.io/trgr5899/csci_1300_trevor_green
// Project 2
/*Algorithm- create a program that uses the library class
*Makes a menu that Read book file, Read user file,  Print book list Get rating Find number of books user rated View ratings, Get average rating
, Add a user, Checkout a book, Get recommendations and Quit
first we have to include the all the classes, then in each case we have to call the appropriate functions*/
#include <iostream>



#include "User.h"
#include "Book.h"
#include "Library.h"
#include "Library.cpp"
using namespace std;


// CS1300 Spring 2019
// Author: my name
// Recitation: 123 – Favorite TA
// Cloud9 Workspace Editor Link: https://ide.c9.io/…
// Project 2




// -- library class: constructor

// -- library class: getters/setters

// -- library class: methods (and other functions)


// printAllBooks
// cout << "Here is a list of books" << endl;

// viewRatings
// cout << username << " does not exist." << endl;
// cout << username << " has not rated any books yet." << endl;
// cout << "Here are the books that "<< name << " rated" << endl;
// cout << "Title : " << title << endl;
// cout << "Rating : " << rating << endl;
// cout << "-----" << endl;

// getRecommendations
// cout << username << " does not exist." << endl;
// cout << "Here is the list of recommendations" << endl;
// cout << title << " by " << author << endl;
// cout << "There are no recommendations for " << username <<" at present."<<endl;



/* displayMenu:
 * displays a menu with options
 * DO NOT MODIFY THIS FUNCTION
 */
void displayMenu(){
	cout << "Select a numerical option:" << endl;
	cout << "======Main Menu=====" << endl;
	cout << "1. Read book file" << endl;
	cout << "2. Read user file" << endl;
	cout << "3. Print book list" << endl;
	cout << "4. Get rating" << endl;
	cout << "5. Find number of books user rated" << endl;
	cout << "6. View ratings" << endl;
	cout << "7. Get average rating" << endl;
	cout << "8. Add a user" << endl;
	cout << "9. Checkout a book" << endl;
	cout << "10. Get recommendations" << endl;
	cout << "11. Quit" << endl;
}


int main(int argc, char const *argv[]) {


	// temp variables
    string choice;
    string bookFileName;
    string userFileName;
    string userName, bookTitle;
    string strRating;
    Library myLibrary;
    int sizeBook=50;
    int sizeUser=100;
    int numBook=0;
    int numUser=0;
    int rv=0;
    int rv1=0;
    int rating=0;
    int count=0;
    double avgRating=0.0000;
    int add=0;
    int check=0;
    int ratingB=0;

    while (choice != "11") {
        displayMenu();

        // take a menu opton
        getline(cin, choice);

        // convert the `choice` to an integer
        int menuChoice = stoi(choice);

        switch (menuChoice) {

            case 1:
                // Initialize library -- readBooks
                cout << "Enter a book file name:" << endl;
                getline(cin, bookFileName);

                //////////////////////////////////////////////////////////////////////////
                 rv=myLibrary.readBooks(bookFileName);
                numBook=myLibrary.getNumBooks();
                //////////////////////////////////////////////////////////////////////////

                // Use the below messages and match them to the return code.
                // readBooks returned -1
                if (rv==-1)
                {
                 cout << "No books saved to the database." << endl;
                }
                // readBooks returned -2
                else if(rv==-2)
                {
                 cout << "Database is already full. No books were added." << endl;
                }
                // readBooks returned book arr size
                else if(rv==sizeBook)
                {
                 cout << "Database is full. Some books may have not been added." << endl;
                }
                // readBooks returned otherwise
                else
                {
                 cout << "Total books in the database: " << numBook << endl;
                }



                cout << endl;
                break;

            case 2:
                //  Initialize user catalog -- readRatings

                cout << "Enter a user file name:" << endl;
                getline(cin, userFileName);


                //////////////////////////////////////////////////////////////////////////
                rv1=myLibrary.readRatings(userFileName);
                numUser=myLibrary.getNumUsers();
                //////////////////////////////////////////////////////////////////////////

                //Use the below messages and match them to the return code.
                // readRatings returned -1
                if (rv1==-1){
                cout << "No users saved to the database." << endl<<endl;
                break;
                }
                // readRatings returned -2
                if (rv1==-2)
                {
                 cout << "Database is already full. No users were added." << endl;
                }
                // readRatings returned user arr size
                if (rv1==100)
                {
                 cout << "Database is full. Some users may have not been added." << endl;
                }
                // readRatings returned otherwise
                else
                {
                cout << "Total users in the database: " << numUser << endl;
                }
                cout << endl;
                break;

            case 3:
                // Display library -- printAllBooks
               if (numBook==0)
                {
                cout << "Database has not been fully initialized." << endl<<endl;
                break;
                }
                //////////////////////////////////////////////////////////////////////////
                myLibrary.printAllBooks();
                //////////////////////////////////////////////////////////////////////////


                // If the database has not been initialized



                cout << endl;
                break;

            case 4:
                //  Get a rating -- getRating

                //////////////////////////////////////////////////////////////////////////
                if (numUser==0)
                {
                    cout << "Database has not been fully initialized." << endl;
                    break;
                }
                //////////////////////////////////////////////////////////////////////////

                // Use the below messages and match them to the return code. Update variables as needed.


                // If the database has not been initialized
                // cout << "Database has not been fully initialized." << endl;

        		// take user name
                cout << "Enter username:" << endl;
                getline(cin, userName);

                // take book title
                cout << "Enter book title:" << endl;
                getline(cin, bookTitle);
                rating=myLibrary.getRating(userName,bookTitle);
                // getRating returned 0
                if (rating==0)
                {
                 cout << userName << " has not rated " << bookTitle << endl<<endl;
                 break;
                }
                // getRating returned -3
                if (rating==-3)
                {
                cout << userName << " or " << bookTitle << " does not exist." << endl;
                }
                // getRating returned other than 0 or -3
                else
                {
                 cout << userName << " rated " << bookTitle << " with " << rating << endl;
                }
                cout << endl;
                break;

            case 5:
                // Get number of books the user has rated -- getCountReadBooks

                // If the database has not been initialized
                if (numBook==0)
                {
                cout << "Database has not been fully initialized." << endl<<endl;
                break;
                }
                cout << "Enter username:" << endl;
                getline(cin, userName);
                count=myLibrary.getCountReadBooks(userName);
                // getCountReadBooks returned 0
                if (count==0){
                cout << userName << " has not rated any books." << endl<<endl;
                break;
                }
                // getCountReadBooks returned -3
                if (count==-3)
                {
                cout << userName << " does not exist." << endl;
                }
                else 
                {
                // getCountReadBooks returned other than 0 or -3
                cout << userName << " rated " << count << " books." << endl;
                }


            	cout << endl;
                break;

            case 6:
                // View user’s ratings -- viewRatings

                // If the database has not been initialized
                // cout << "Database has not been fully initialized." << endl;
                if (numBook==0)
                {
                cout << "Database has not been fully initialized." << endl<<endl;
                break;
                }
        		// take user name
                cout << "Enter username:" << endl;
                getline(cin, userName);
                myLibrary.viewRatings(userName);
                

            	cout << endl;
                break;

            case 7:
                // Calculate the average rating for the book -- calcAvgRating

                if (numBook==0)
                {
                cout << "Database has not been fully initialized." << endl<<endl;
                break;
                }
        		// take book title
                cout << "Enter book title:" << endl;
                getline(cin, bookTitle);
                avgRating=myLibrary.calcAvgRating(bookTitle);
                // calcAvgRating returned -3
                if (avgRating==-3)
                {
                cout << bookTitle << " does not exist." << endl;
                }
                // calcAvgRating returned other than -3
                else
                {
                cout << "The average rating for " << bookTitle << " is " << avgRating << endl;
                }

            	cout << endl;
                break;
            case 8:
                // Add a user to the database -- addUser
        		// take user name
                cout << "Enter username:" << endl;
                getline(cin, userName);
                add=myLibrary.addUser(userName);
                // addUser returned 1
                if (add==1)
                {
                cout << "Welcome to the library " << userName << endl;
                }
                
                // addUser returned 0
                if (add==0)
                {
                cout << userName << " already exists in the database." << endl;
                }
                // addUser returned -2
                if (add==-2)
                {
                cout << "Database is already full. " << userName << " was not added." << endl;
                }

            	cout << endl;
                break;
            case 9:
                // Check out the book -- checkOutBook

                if (numBook==0)
                {
                cout << "Database has not been fully initialized." << endl<<endl;
                break;
                }
        		// take user name
                cout << "Enter username:" << endl;
                getline(cin, userName);

                // take book title
                cout << "Enter book title:" << endl;
                getline(cin, bookTitle);

                // take rating
                cout<<"Enter rating for the book:"<<endl;
                getline(cin, strRating);
                ratingB=stoi(strRating);
                 check=myLibrary.checkOutBook(userName,bookTitle,ratingB);

                // checkOutBook returned 1
                if (check==1){
                cout << "We hope you enjoyed your book. The rating has been updated." << endl;
                }
                // checkOutBook returned -4
                if (check==-4)
                {
                cout << strRating << " is not valid." << endl; 
                }
                // checkOutBook returned -3
                if (check==-3)
                {
                cout << userName << " or " << bookTitle << " does not exist." << endl;
                }

            	cout << endl;
                break;
            case 10:
                // get recommendations  -- getRecommendations

                if (numBook==0)
                {
                cout << "Database has not been fully initialized." << endl<<endl;
                break;
                }

        		// take user name
                cout << "Enter username:" << endl;
                getline(cin, userName);
                myLibrary.getRecommendations(userName);


            	cout << endl;
                break;

            case 11:
                // quit
                cout << "good bye!" << endl;
                break;

            default:
                cout << "invalid input" << endl;
                cout << endl;
        }
    }

    return 0;
}