#include <iostream>
#include <math.h>
#include <iomanip>
#include <string>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <fstream>
#include <stdio.h>
#include "User.h"
#include "Book.h"
#include "Book.cpp"
#include "User.cpp"
#include "Library.h"
#include <string.h>

using namespace std;
int SSDnum(int m,int check,int numBooks,User users[])
{int SSD=0;
int diff=0;
            for (int n=0;n<numBooks;n++)
                {
                    int first=users[check].getRatingAt(n);
                    int second=users[m].getRatingAt(n);
                    diff=first-second;
                    SSD=SSD+(diff*diff);
                }
                return SSD;
            
            return SSD;
}
int checkTitle(Book titles[],string title,int numbooks)//this function grabs the titles array of type Book and the title we are checking for
    {
    for(int i=0;i<numbooks;i++)//this loops through all the titles stored in the array
    {
        string use;
        use=titles[i].getTitle();
        for (int j=0;j<use.length();j++)//this makes the string from any index lowercase
        {
            use[j]=tolower(use[j]);
        }
                
        if (use==title)//checks to see if any of the titles match the one we are looking for, if so then return its location in the array
        {
        return i;
        break;
        }
    }
    return numbooks;
}
int checkUser(User user[],string username,int numusers)//checks for the corresponding username
    {
    for(int i=0;i<numusers;i++)//loops through each index of users
    {
        string use;
        use=user[i].getUsername();
        for (int j=0;j<use.length();j++)//makes every string lowercase
        {
            
            use[j]=tolower(use[j]);
        }
        if (use==username)//if the string in that index matches the one we are looking for then return its location
        {
            return i;
            break;
        }
    
    }
    return numusers;
}
int splitz (string str, char c,User users[],int numu,int maxr)
{
    if (str.length() == 0) 
    {
        return 0;
    }
    string word = "";
    int j = numu;
    int l= numu;
    int k=0;
    int books=0;
    int numbe=0;
    str = str + c;
    for (int i = 0; i < str.length(); i++)//goes through each character in the string 
    {
        if (str[i] == c) 
        {

            if (k==0)
            {
        	    if (word.length() == 0) continue;//the first word gets put into the Username of User array
        	       users[j].setUsername(word);
                //cout << word << endl; 

                word = "";
                k=1;
            }
            else 
            {
                numbe=stoi(word);
                users[l].setRatingAt(books,numbe);//after that the rest of the characters are converted into ints and go into ratings
                books++;
                word = "";
            }
        } else {
            word = word + str[i];
        }
    }
}
int split (string str, char c,Book bookss[],int length)//changed split to output and take in one Book array
{
    
    if (str.length() == 0) {
        return 0;
    }
    string word = "";
    int j = length;
    int l= length;
    int k=0;
    str = str + c;
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] == c) 
        {

            if (k==0)//set author for book array
            {
        	    if (word.length() == 0) continue;
        	    bookss[j].setAuthor(word);
                //cout << word << endl; 
                j++;
                word = "";
                k=1;
            }
            else 
            {
               // cout<<word<<endl;
                bookss[l].setTitle(word);//set title of book array 
                l++;
                word = "";
                k=0;  
            }
        } 
        else 
        {
            word = word + str[i];
        }
    }
}
Library::Library()
{
    
}
int Library::getSizeBook()
{
    return sizeBook;
}
int Library::getSizeUser()
{
    return sizeUser;
}
int Library::getNumBooks()
{
    return numBooks;
}
int Library::getNumUsers()
{
    return numUsers;
}
int Library::readBooks(string file)
{
int j= numBooks;
if (sizeBook<=numBooks)
{
    return -2;
}
ifstream myfile;
//open the file file1.txt with the file stream
myfile.open(file);
if (myfile.is_open())
{
    // do things with the file
    string line = "";
    
    // read each line from the file
    while (getline(myfile, line))// takes each line then puts line in split function
    {
        if (line.length()>0)
        {
            split(line,',',books,j);
            j++;
        }
    
        if (myfile.eof())
        {
            numBooks=j;
           return j;
        }
        if (j>=sizeBook)
        {
            numBooks=j;
        return j;
        }
    }
}
else 
{
    return -1;
}
// closing the file
myfile.close();
numBooks=j;
return j;

}
void Library::printAllBooks()
{

if (numBooks<=0)//checks to see if books are stored
{
    cout <<"No books are stored"<<endl;

}
else if (numBooks>0)//if so then ouput each corresponding index or each array
{
    cout<<"Here is a list of books"<<endl;
    for (int i=0;i<numBooks;i++)
    {
     cout << books[i].getTitle() << " by " << books[i].getAuthor() << endl;
    
    }
}
}
int Library::readRatings(string file)
{
    if (numUsers>=sizeUser)//retrun -2 if there is not enough rows or to many users
    {
        return -2;
    }
    else
    {

        ifstream myfile;
        myfile.open(file);
    if (myfile.is_open())//if the file opened
    {
        string line = "";
        int j= numUsers;
        while (getline(myfile, line)) //get line
        {
            if (j>=sizeUser)//this is for segmentation error
            {
                numUsers=j;
                return j;
            }
            if (line.length()>0)//if the line is not empty go on to ssplit function
            {
                splitz(line,',',users,j,sizeUser);
                j++;
            }
            if (myfile.eof())
            {
                numUsers=j;
            return j;
            }
    
    
        }
        if (j>=sizeUser)//for seg error
        {
            numUsers=j;
            return j;
        }
        numUsers=j;
        return j;
    }
    else 
    {
        return -1;
    }
// closing the file
myfile.close();
}
}
int Library::getRating(string username,string title)
{
    for (int k=0;k<username.length();k++)//make the username we are looking for all lower case
    {
        username[k]=tolower(username[k]);
    }
    for (int r=0;r<title.length();r++)//make the title we are looking for all lower case
    {
        title[r]=tolower(title[r]);
    }
    int check=checkUser(users,username,numUsers);//gives us location of the user
    int check2=checkTitle(books,title,numBooks);//gives location of the title
   
    if ((check==numUsers)||(check2==numBooks))//return -3 if the username or title were not found
    {
        return -3;
    }
    else
    {
        int rating=users[check].getRatingAt(check2);//put the location of the user and title into User array to get the rating out of the array
        return rating;
    }
}
int Library::getCountReadBooks(string username)
{
    int m=0;
    int g=0;
    for (int k=0;k<username.length();k++)//make the username we are looking for all lower case
    {
        username[k]=tolower(username[k]);
    }
    int check=checkUser(users,username,numUsers);//gives us location of the user
   
    if (check==numUsers)//return -3 if the username or title were not found
    {
        return -3;
    }
    else
    {
        for (int b=0;b<numBooks;b++)
        {
        int rating=users[check].getRatingAt(b);//put the location of the user and title into User array to get the rating out of the array
        if(rating==0)
        {
            m=m;
        }
        else
        {
            m++;
        }
        }
    }
    return m;
   
}
void Library::viewRatings(string username)
{
 string original=username;
    int m=0;
    int g=0;
    for (int k=0;k<username.length();k++)//make the username we are looking for all lower case
    {
        username[k]=tolower(username[k]);
    }
    int check=checkUser(users,username,numUsers);//gives us location of the user
   
    if (check==numUsers)//return -3 if the username or title were not found
    {
        cout<<original<<" does not exist.";
    }
    else
    {
        for (int b=0;b<numBooks;b++)
        {
        int rating=users[check].getRatingAt(b);//put the location of the user and title into User array to get the rating out of the array
        if(rating==0)
        {
            for(int v=b+1;v<numBooks;v++)
           {
            int rat=users[check].getRatingAt(v);//put the location of the user and title into User array to get the rating out of the array
            if (rat==0)
            {
                m++;
                if (m==numBooks)
                {int p=b+1;
                    if (users[check].getRatingAt(p)==0)
                    {
                    cout<<original<<" has not rated any books yet.";
                    }
                }
            }
            }
        }
        else
        {
            if(g==0)
            {
            cout<<"Here are the books that "<<original<<" rated"<<endl;
            g=1;
            }
            cout<<"Title : "<< books[b].getTitle()<<endl;
            cout<<"Rating : "<<rating<<endl;
            cout<<"-----"<<endl;
            
        }
        }
    }
   
}
double Library::calcAvgRating(string title)
{
    double total=0;
    double q=0;
    for (int r=0;r<title.length();r++)//make the title we are looking for all lower case
    {
        title[r]=tolower(title[r]);
    }
    int check2=checkTitle(books,title,numBooks);//gives location of the title
   
    if (check2==numBooks)//return -3 if the username or title were not found
    {
        return -3;
    }
    else
    {
        for(int z=0;z<numUsers;z++)
        {
        double rating=users[z].getRatingAt(check2);//put the location of the user and title into User array to get the rating out of the array
        
        if (rating!=0)
        {
            q++;
            total=total+rating;
        }
            
        }
        if (q==0)
        {
            return 0;
        }
        double average=total/q;
        return average;
    }
    
}
int Library::addUser(string username)
{
    string usernameL=username;
    if (numUsers==100)
    {
        return -2;
    }

    
    for (int k=0;k<username.length();k++)//make the username we are looking for all lower case
    {
        username[k]=tolower(username[k]);
    }

    
    for (int f=0;f<numUsers;f++)
    {
        string use;
        use=users[f].getUsername();
        for (int j=0;j<use.length();j++)//makes every string lowercase
        {
            
            use[j]=tolower(use[j]);
        }
        if (use==username)//if the string in that index matches the one we are looking for then return its location
        {
            return 0;
        }
    }
    for(int i=0;i<=numUsers;i++)//loops through each index of users
    {
        string use2;
        use2=users[i].getUsername();
        if (use2=="")//if the string in that index matches the one we are looking for then add user
        {
            users[i].setUsername(username);
            for (int j=0;j<numBooks;j++)
            {
            users[i].setRatingAt(j,0);
            }
            numUsers=numUsers+1;
            return 1;
        }
    
    }
    
}
int Library::checkOutBook(string username, string title, int rating)
{
    if ((rating>5)||(rating<0))
    {
        return -4;
    }
    for (int k=0;k<username.length();k++)//make the username we are looking for all lower case
    {
        username[k]=tolower(username[k]);
    }
    for (int r=0;r<title.length();r++)//make the title we are looking for all lower case
    {
        title[r]=tolower(title[r]);
    }
    int check=checkUser(users,username,numUsers);//gives us location of the user
    int check2=checkTitle(books,title,numBooks);//gives location of the title
   
    if ((check==numUsers)||(check2==numBooks))//return -3 if the username or title were not found
    {
        return -3;
    }
    else
    {
        users[check].setRatingAt(check2,rating);//put the location of the user and title into User array to get the rating out of the array
        return 1;
    } 
}
void Library::getRecommendations(string username)
{
    int g=0;
    int mostsim=100000;
    int locat=0;
    int dum=0;
    int d=0;
    for (int k=0;k<username.length();k++)//make the username we are looking for all lower case
    {
        username[k]=tolower(username[k]);
    }
    int check=checkUser(users,username,numUsers);//gives us location of the user
   
    if (check==numUsers)//return -3 if the username or title were not found
    {
        cout<<username<<" does not exist.";
    }
    else
    {
        for (int m=0;m<numUsers;m++)
        {
            int similar=SSDnum(m,check,numBooks,users);
            if (similar==0)
            {
                m=m;
            }
            else
            {
                if (similar<mostsim)
                {
                    mostsim=similar;
                    locat=m;
                    
                }
                
            }
            
        }       
        if (mostsim==0)
        {
            cout<<"There are no recommendations for "<<username<<" at present."<<endl;
        }
        else
        {
            
                for (int n=0;n<numBooks;n++)
                {
                    int rat1=users[check].getRatingAt(n);
                    if (rat1==0)
                    {
                        int rat=users[locat].getRatingAt(n);
                        if ((rat>=3)&&(rat<=5))
                        {
                              d++;                  
                            if (d>5)
                            {
                                break;
                            }
                        if (dum==0)
                        {
                         cout<<"Here is the list of recommendations"<<endl;
                         dum=1;
                            
                        }
                        cout<<books[n].getTitle()<<" by "<<books[n].getAuthor()<<endl;
                    }
                    }
                }
                if (dum==0)
                {
                    cout<<"There are no recommendations for "<<username<<" at present."<<endl;
                }
        }
    }
}



