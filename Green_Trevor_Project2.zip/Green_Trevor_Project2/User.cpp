// CS1300 Spring 2019
// Author: Trevor Green
// Recitation: T. Umada
// Cloud9 Workspace Editor Link:https://ide.c9.io/trgr5899/csci_1300_trevor_green
// Project 2
/*Algorithm-
*create functions that get and set book username,number of ratings, the ratings themselves and the size
*/
#include <iostream>
#include <math.h>
#include <iomanip>
#include <string>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <fstream>
#include "User.h"
#include <stdio.h>
#include <string.h>
using namespace std;

User::User()
{
  username="";
  numRatings=0;
  for (int i=0;i<size;i++)
  {
    ratings[i]=0;
  }
}
User::User(string usern,int rating[],int numRating)
{
  username=usern;
  for (int i=0;i<size;i++)
  {
    ratings[i]=rating[i];
  }
  numRatings=numRating;
}
string User::getUsername()
{
    return username;
}
void User::setUsername(string usern)
{
    username=usern;
}
int User::getRatingAt(int index)
{
    if (index>=size)
    {
        return -1;
    }
    int rate=ratings[index];
    return rate;
}
bool User::setRatingAt(int index,int value)
{
    if (index>=size)
    {
        return false;
    }
    if ((value<=5)&&(value>=0))
    {
    ratings[index]=value;
    return true;
    }
    else
    {
        return false;
    }
}
int User::getNumRatings()
{
    return numRatings;
}
void User::setNumRatings(int value)
{
    numRatings=value;
}
int User::getSize()
{
    
    return size;
}